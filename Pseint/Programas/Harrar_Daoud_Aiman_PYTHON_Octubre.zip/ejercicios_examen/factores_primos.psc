// ============================================================
// FUNCI�N PedirNumero
// No recibe nada. Pide un n�mero al usuario y lo devuelve,
// asegur�ndose de que sea mayor que 1 (el 0 y el 1 no tienen
// factores primos).
// ============================================================
Funcion n <- PedirNumero(mensaje)
	// "n" es la variable que devolver� la funci�n
	Definir n Como Entero
	
	// Se repite la pregunta hasta que el n�mero sea v�lido
	Repetir
		Escribir "Introduce un n�mero mayor que 1: "
		Leer n
	Hasta Que n > 1
	
	// Al llegar a FinFuncion, se devuelve el valor de "n"
FinFuncion


// ============================================================
// SUBPROCESO MostrarFactores
// Recibe un n�mero y escribe en pantalla su descomposici�n
// en factores primos. Es un subproceso (no una funci�n)
// porque no devuelve nada: solo escribe.
// ============================================================
SubProceso MostrarFactores(numero)
	// n: copia del n�mero que iremos dividiendo hasta llegar a 1
	// divisor: n�mero con el que probamos a dividir
	Definir n, divisor Como Entero
	// primero: indica si todav�a no hemos escrito ning�n factor
	Definir primero Como Logico
	
	// Trabajamos sobre una copia para no perder el n�mero original
	n <- numero
	// Empezamos probando con 2, que es el primer n�mero primo
	divisor <- 2
	// Al principio a�n no se ha escrito ning�n factor
	primero <- Verdadero
	
	// Escribimos el inicio, por ejemplo "60 = "
	// "Sin Saltar" hace que lo siguiente siga en la misma l�nea
	Escribir Sin Saltar numero, " = "
	
	// Repetimos mientras quede algo por dividir
	// (cuando n llega a 1, ya hemos sacado todos los factores)
	Mientras n > 1 Hacer
		
		// Comprobamos si la divisi�n es exacta (resto 0)
		Si n MOD divisor = 0 Entonces
			
			// El divisor es un factor primo: hay que escribirlo
			Si primero Entonces
				// Si es el primer factor, se escribe solo, sin "x"
				Escribir Sin Saltar divisor
				// A partir de ahora ya no ser� el primero
				primero <- Falso
			SiNo
				// Si ya hab�a factores antes, se escribe " x " delante
				Escribir Sin Saltar " x ", divisor
			FinSi
			
			// Dividimos n entre el factor encontrado.
			// No aumentamos el divisor, porque puede volver a
			// dividir (por ejemplo, el 2 aparece dos veces en 60)
			n <- n / divisor
			
		SiNo
			// La divisi�n no es exacta: este divisor ya no sirve,
			// as� que probamos con el siguiente n�mero.
			// Los que no son primos (4, 6, 8...) nunca dividir�n,
			// porque sus factores ya se quitaron antes
			divisor <- divisor + 1
		FinSi
		
	FinMientras
	
	// Salto de l�nea final para terminar la salida
	Escribir ""
FinSubProceso


// ============================================================
// PROGRAMA PRINCIPAL
// Pide un n�mero y muestra su descomposici�n en factores primos
// usando las funciones anteriores.
// ============================================================
Algoritmo factores_primos
	Definir numero Como Entero
	
	// Llamamos a la funci�n y guardamos lo que devuelve.
	// Lleva flecha porque la funci�n devuelve un valor
	numero <- PedirNumero("Introduce un n�mero mayor que 1")
	
	// Llamamos al subproceso para que escriba los factores.
	// Va sin flecha porque el subproceso no devuelve nada
	MostrarFactores(numero)

FinAlgoritmo